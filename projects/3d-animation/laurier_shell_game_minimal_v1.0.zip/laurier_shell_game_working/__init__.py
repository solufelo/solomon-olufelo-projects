"""
Laurier Football Shell Game - Minimal Working Version
====================================================

Vertical slice approach - core functionality only.
Build incrementally from here.

Author: Solomon Olufelo
Version: 1.0.0 (Minimal)
Blender: 4.5+
"""

bl_info = {
    "name": "Laurier Football Shell Game",
    "author": "Solomon Olufelo",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "3D Viewport > Sidebar > Laurier Football",
    "description": "Minimal working shell game animation",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}

import bpy
import mathutils
from math import sin, cos, pi
import random
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import FloatProperty, IntProperty, BoolProperty, EnumProperty, PointerProperty

# ============================================================================
# PROPERTIES
# ============================================================================

class LaurierShellGameProperties(PropertyGroup):
    """Simple properties for the shell game."""
    
    # Basic settings
    duration_sec: FloatProperty(
        name="Duration",
        description="Animation duration in seconds",
        default=8.0,
        min=1.0,
        max=30.0
    )
    
    shuffle_amplitude: FloatProperty(
        name="Movement Size",
        description="How far helmets move",
        default=12.0,
        min=1.0,
        max=50.0
    )
    
    spacing_buffer: FloatProperty(
        name="Spacing",
        description="Distance between helmets",
        default=8.0,
        min=1.0,
        max=20.0
    )
    
    reveal_target: IntProperty(
        name="Target Helmet",
        description="Which helmet hides the football (1, 2, or 3)",
        default=2,
        min=1,
        max=3
    )

# ============================================================================
# CORE ANIMATION ENGINE
# ============================================================================

class LaurierShellGameEngine:
    """Simple animation engine."""
    
    def __init__(self, props):
        self.props = props
        self.config = {
            "duration_sec": props.duration_sec,
            "fps": 24,
            "shuffle_amplitude": props.shuffle_amplitude,
            "spacing_buffer": props.spacing_buffer,
            "reveal_target": props.reveal_target,
        }
    
    def get_empty_object(self, name):
        """Get empty object by name."""
        obj = bpy.data.objects.get(name)
        if not obj:
            raise ValueError(f"Required empty '{name}' not found!")
        return obj
    
    def calculate_helmet_positions(self, frame):
        """Calculate positions for all three helmets."""
        positions = {}
        
        # Base positions
        base_positions = {
            1: mathutils.Vector((-self.config["spacing_buffer"], 0, 0)),
            2: mathutils.Vector((0, 0, 0)),
            3: mathutils.Vector((self.config["spacing_buffer"], 0, 0))
        }
        
        for helmet_num in [1, 2, 3]:
            # Simple sine wave movement
            t = frame / (self.config["fps"] * self.config["duration_sec"])
            phase_offset = (helmet_num - 1) * (2 * pi / 3)
            
            horizontal_offset = self.config["shuffle_amplitude"] * sin(2 * pi * 2 * t + phase_offset)
            
            pos = base_positions[helmet_num].copy()
            pos.x += horizontal_offset
            
            positions[helmet_num] = pos
        
        return positions
    
    def animate_helmets(self):
        """Create helmet animation."""
        total_frames = int(self.config["duration_sec"] * self.config["fps"])
        
        for frame in range(1, total_frames + 1):
            positions = self.calculate_helmet_positions(frame)
            
            for helmet_num in [1, 2, 3]:
                empty_name = f"Empty_{helmet_num}"
                empty_obj = self.get_empty_object(empty_name)
                empty_obj.location = positions[helmet_num]
                empty_obj.keyframe_insert(data_path="location", frame=frame)
    
    def animate_football(self):
        """Animate football to follow target helmet."""
        football_ctrl = self.get_empty_object("Football_CTRL")
        target_empty = self.get_empty_object(f"Empty_{self.config['reveal_target']}")
        
        total_frames = int(self.config["duration_sec"] * self.config["fps"])
        
        for frame in range(1, total_frames + 1):
            football_ctrl.location = target_empty.location
            football_ctrl.keyframe_insert(data_path="location", frame=frame)
    
    def run_animation(self):
        """Run the complete animation."""
        try:
            # Set scene frame rate
            bpy.context.scene.render.fps = self.config["fps"]
            bpy.context.scene.frame_set(1)
            
            # Create animations
            self.animate_helmets()
            self.animate_football()
            
            # Set frame range
            total_frames = int(self.config["duration_sec"] * self.config["fps"])
            bpy.context.scene.frame_start = 1
            bpy.context.scene.frame_end = total_frames
            
            return True, f"Animation complete! Football under helmet {self.config['reveal_target']}"
        except Exception as e:
            return False, str(e)

# ============================================================================
# OPERATOR
# ============================================================================

class LAURIER_OT_create_shell_game(Operator):
    """Create shell game animation."""
    bl_idname = "laurier.create_shell_game"
    bl_label = "Create Animation"
    bl_description = "Generate shell game animation"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.laurier_shell_game
        
        engine = LaurierShellGameEngine(props)
        success, message = engine.run_animation()
        
        if success:
            self.report({'INFO'}, message)
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, f"Animation failed: {message}")
            return {'CANCELLED'}

# ============================================================================
# UI PANEL
# ============================================================================

class LAURIER_PT_shell_game_panel(Panel):
    """Simple UI panel."""
    bl_label = "Laurier Football Shell Game"
    bl_idname = "LAURIER_PT_shell_game_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Laurier Football"
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.laurier_shell_game
        
        # Header
        layout.label(text="🏈 Shell Game Animation")
        
        # Basic controls
        layout.prop(props, "duration_sec")
        layout.prop(props, "shuffle_amplitude")
        layout.prop(props, "spacing_buffer")
        layout.prop(props, "reveal_target")
        
        # Create button
        layout.separator()
        layout.operator("laurier.create_shell_game", text="Create Animation", icon='PLAY')
        
        # Help
        layout.separator()
        layout.label(text="Setup:")
        layout.label(text="• Empty_1, Empty_2, Empty_3")
        layout.label(text="• Football_CTRL")
        layout.label(text="• Parent helmets to empties")

# ============================================================================
# REGISTRATION
# ============================================================================

classes = (
    LaurierShellGameProperties,
    LAURIER_OT_create_shell_game,
    LAURIER_PT_shell_game_panel,
)

def register():
    """Register the addon."""
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.laurier_shell_game = PointerProperty(type=LaurierShellGameProperties)
    print("🏈 Laurier Football Shell Game (Minimal) registered!")

def unregister():
    """Unregister the addon."""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.laurier_shell_game
    print("🏈 Laurier Football Shell Game unregistered.")

if __name__ == "__main__":
    register()