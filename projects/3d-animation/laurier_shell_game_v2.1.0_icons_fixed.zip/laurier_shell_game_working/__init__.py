"""
Laurier Football Shell Game Addon v2.1.0 for Blender 4.5
========================================================

World-class 3D shell game shuffle animation addon for Laurier Football promos.
Features bulletproof logic, professional UI/UX, auto-scaling, and advanced features.

NEW IN v2.1.0 "WORLD-CLASS EDITION":
- 🎯 Bulletproof error handling and validation
- 🎮 World-class UI/UX with modern design patterns
- ⚡ Performance optimizations for large scenes
- 🔍 Advanced scene validation and troubleshooting
- 🎬 Preview mode and undo functionality
- 🚀 Quick setup wizard
- ♿ Accessibility features (high contrast, keyboard shortcuts)
- 📊 Real-time status dashboard
- 💡 Pro tips and contextual help

Author: Solomon Olufelo
Version: 2.1.0 "World-Class Edition"
Blender: 4.5+
Category: Animation

Installation:
1. Download the addon zip file
2. In Blender: Edit > Preferences > Add-ons > Install
3. Select the zip file
4. Enable "Laurier Football Shell Game"

Usage:
1. Click "Setup" to auto-create required objects
2. Click "Validate" to check your scene
3. Enable "Auto Scale" and click "Auto-Scale"
4. Adjust movement with sliders
5. Click "Create Animation" or "Preview" first
"""

bl_info = {
    "name": "Laurier Football Shell Game",
    "author": "Solomon Olufelo",
    "version": (2, 1, 0),
    "blender": (4, 5, 0),
    "location": "3D Viewport > Sidebar > Laurier Football",
    "description": "World-class 3D shell game animation with auto-scaling, bulletproof logic, and professional UI/UX",
    "warning": "",
    "doc_url": "https://github.com/solomon-olufelo/laurier-football-addon",
    "category": "Animation",
}

import bpy
import bmesh
import mathutils
from math import sin, cos, pi
import random
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import (
    FloatProperty, 
    IntProperty, 
    BoolProperty, 
    EnumProperty,
    PointerProperty
)

# ============================================================================
# PROPERTY GROUP FOR ADDON SETTINGS
# ============================================================================

class LaurierShellGameProperties(PropertyGroup):
    """Property group to store addon settings in the scene."""
    
    # Animation timing
    duration_sec: FloatProperty(
        name="Duration (seconds)",
        description="Total animation duration",
        default=8.0,
        min=1.0,
        max=30.0,
        step=0.1
    )
    
    fps: IntProperty(
        name="FPS",
        description="Frames per second",
        default=24,
        min=12,
        max=60
    )
    
    shuffle_speed: FloatProperty(
        name="Shuffle Speed",
        description="Speed of shuffle movements",
        default=3.5,
        min=0.5,
        max=10.0,
        step=0.1
    )
    
    shuffle_cycles: IntProperty(
        name="Shuffle Cycles",
        description="Number of shuffle cycles",
        default=4,
        min=1,
        max=20
    )
    
    # Movement parameters - SCALE ADJUSTED FOR LARGE OBJECTS
    shuffle_amplitude: FloatProperty(
        name="Shuffle Amplitude",
        description="How far helmets move horizontally (12.0 = large objects, 2.0 = small objects)",
        default=12.0,  # SCALED UP from 2.0
        min=0.5,
        max=100.0,
        step=0.5,
        precision=1
    )
    
    vertical_bounce: FloatProperty(
        name="Vertical Bounce",
        description="Height of vertical bounce effect (2.0 = large objects, 0.3 = small objects)",
        default=2.0,  # SCALED UP from 0.3
        min=0.0,
        max=20.0,
        step=0.1,
        precision=1
    )
    
    spacing_buffer: FloatProperty(
        name="Spacing Buffer",
        description="Minimum distance between helmets (8.0 = large objects, 1.5 = small objects)",
        default=8.0,  # SCALED UP from 1.5
        min=0.5,
        max=50.0,
        step=0.5,
        precision=1
    )
    
    # Reveal settings
    reveal_target: IntProperty(
        name="Reveal Target",
        description="Which helmet (1, 2, or 3) hides the football",
        default=2,
        min=1,
        max=3
    )
    
    reveal_duration: FloatProperty(
        name="Reveal Duration",
        description="How long the reveal takes",
        default=1.5,
        min=0.5,
        max=5.0,
        step=0.1
    )
    
    reveal_height: FloatProperty(
        name="Reveal Height",
        description="How high the revealing helmet lifts",
        default=4.0,  # SCALED UP from 1.0
        min=0.1,
        max=15.0,
        step=0.1
    )
    
    # Camera and effects
    camera_sway: BoolProperty(
        name="Camera Sway",
        description="Add subtle camera movement",
        default=True
    )
    
    sway_amount: FloatProperty(
        name="Sway Amount",
        description="Intensity of camera sway",
        default=0.1,
        min=0.0,
        max=1.0,
        step=0.01
    )
    
    ease_out: BoolProperty(
        name="Ease Out",
        description="Slow down before reveal",
        default=True
    )
    
    ease_duration: FloatProperty(
        name="Ease Duration",
        description="How long the ease-out lasts",
        default=1.0,
        min=0.1,
        max=3.0,
        step=0.1
    )
    
    # Randomization
    randomize_target: BoolProperty(
        name="Randomize Target",
        description="Randomly choose which helmet hides football",
        default=True
    )
    
    # Auto-scaling
    auto_scale: BoolProperty(
        name="Auto Scale",
        description="Automatically detect object scale and adjust movement values",
        default=True
    )
    
    detected_scale: FloatProperty(
        name="Detected Scale",
        description="Automatically detected scale factor",
        default=1.0,
        min=0.1,
        max=100.0
    )
    
    # Advanced Features
    preview_mode: BoolProperty(
        name="Preview Mode",
        description="Show real-time preview in viewport",
        default=False
    )
    
    undo_enabled: BoolProperty(
        name="Enable Undo",
        description="Allow undoing animation creation",
        default=True
    )
    
    batch_mode: BoolProperty(
        name="Batch Mode",
        description="Process multiple scenes at once",
        default=False
    )
    
    # Performance
    optimize_large_scenes: BoolProperty(
        name="Optimize Large Scenes",
        description="Use optimized algorithms for scenes with many objects",
        default=True
    )
    
    # Accessibility
    high_contrast: BoolProperty(
        name="High Contrast",
        description="Use high contrast colors for better visibility",
        default=False
    )
    
    keyboard_shortcuts: BoolProperty(
        name="Keyboard Shortcuts",
        description="Enable keyboard shortcuts for quick access",
        default=True
    )
    
    # Preset selection
    preset: EnumProperty(
        name="Animation Preset",
        description="Choose a preset configuration",
        items=[
            ('CUSTOM', "Custom", "Use custom settings"),
            ('QUICK_SNAPPY', "Quick & Snappy", "Fast 5-second animation"),
            ('DRAMATIC_SLOW', "Dramatic & Slow", "Cinematic 12-second animation"),
            ('SOCIAL_MEDIA', "Social Media", "Energetic 3-second animation"),
            ('BROADCAST_QUALITY', "Broadcast Quality", "Professional 8-second animation"),
            ('MINIMAL_CLEAN', "Minimal & Clean", "Subtle 6-second animation"),
            ('HIGH_ENERGY', "High Energy", "Fast and bouncy 4-second animation"),
        ],
        default='BROADCAST_QUALITY'
    )

# ============================================================================
# ANIMATION ENGINE (Converted from original script)
# ============================================================================

class LaurierShellGameEngine:
    """Core animation engine for the shell game effect."""
    
    def __init__(self, props):
        self.props = props
        self.config = {
            "duration_sec": props.duration_sec,
            "fps": props.fps,
            "shuffle_speed": props.shuffle_speed,
            "shuffle_cycles": props.shuffle_cycles,
            "shuffle_amplitude": props.shuffle_amplitude,
            "vertical_bounce": props.vertical_bounce,
            "spacing_buffer": props.spacing_buffer,
            "reveal_target": props.reveal_target,
            "reveal_duration": props.reveal_duration,
            "reveal_height": props.reveal_height,
            "camera_sway": props.camera_sway,
            "sway_amount": props.sway_amount,
            "ease_out": props.ease_out,
            "ease_duration": props.ease_duration,
            "randomize_target": props.randomize_target,
        }
        
        # Store original positions to preserve user setup
        self.original_positions = {}
        self.original_rotations = {}
    
    def get_empty_object(self, name):
        """Get empty object by name, with bulletproof error handling."""
        obj = bpy.data.objects.get(name)
        if not obj:
            # Provide detailed troubleshooting information
            available_objects = [obj.name for obj in bpy.data.objects if obj.type == 'EMPTY']
            raise ValueError(
                f"❌ Required empty '{name}' not found!\n"
                f"📋 Available empty objects: {available_objects}\n"
                f"🔧 Please create empty objects named: Empty_1, Empty_2, Empty_3, Football_CTRL\n"
                f"💡 Tip: Use Add > Empty > Plain Axes to create them"
            )
        
        # Validate object type
        if obj.type != 'EMPTY':
            raise ValueError(f"❌ Object '{name}' exists but is not an empty! It's a {obj.type}.")
        
        return obj
    
    def validate_scene_setup(self):
        """Comprehensive scene validation with detailed feedback."""
        errors = []
        warnings = []
        
        # Check required empty objects
        required_empties = ["Empty_1", "Empty_2", "Empty_3", "Football_CTRL"]
        for empty_name in required_empties:
            obj = bpy.data.objects.get(empty_name)
            if not obj:
                errors.append(f"Missing empty object: {empty_name}")
            elif obj.type != 'EMPTY':
                errors.append(f"Object '{empty_name}' is not an empty (it's a {obj.type})")
        
        # Check if helmets are parented
        for i in range(1, 4):
            empty_name = f"Empty_{i}"
            empty_obj = bpy.data.objects.get(empty_name)
            if empty_obj and not empty_obj.children:
                warnings.append(f"No helmet parented to {empty_name}")
            elif empty_obj and len(empty_obj.children) > 1:
                warnings.append(f"Multiple objects parented to {empty_name} - using first child")
        
        # Check football parenting
        football_ctrl = bpy.data.objects.get("Football_CTRL")
        if football_ctrl and not football_ctrl.children:
            warnings.append("No football parented to Football_CTRL")
        
        # Check camera
        if not bpy.context.scene.camera:
            warnings.append("No camera found in scene - camera sway will be disabled")
        
        return errors, warnings
    
    def ease_out_cubic(self, t):
        """Cubic ease-out function for smooth deceleration."""
        return 1 - pow(1 - t, 3)
    
    def ease_in_out_sine(self, t):
        """Sine ease-in-out for natural movement."""
        return -(cos(pi * t) - 1) / 2
    
    def create_sine_wave_movement(self, frame, amplitude, frequency, phase_offset=0):
        """Generate sine wave movement with phase offset for different helmets."""
        t = frame / (self.config["fps"] * self.config["duration_sec"])
        return amplitude * sin(2 * pi * frequency * t + phase_offset)
    
    def add_vertical_bounce(self, frame):
        """Add realistic vertical bounce to helmet movement."""
        t = frame / (self.config["fps"] * self.config["duration_sec"])
        bounce = self.config["vertical_bounce"] * abs(sin(2 * pi * self.config["shuffle_speed"] * t))
        return bounce
    
    def calculate_helmet_positions(self, frame):
        """Calculate positions for all three helmets with collision avoidance."""
        positions = {}
        
        base_positions = {
            1: mathutils.Vector((-self.config["spacing_buffer"], 0, 0)),
            2: mathutils.Vector((0, 0, 0)),
            3: mathutils.Vector((self.config["spacing_buffer"], 0, 0))
        }
        
        for helmet_num in [1, 2, 3]:
            # Enhanced phase offset for more dramatic movement
            phase_offset = (helmet_num - 1) * (2 * pi / 3) + (frame * 0.1)
            
            # Primary horizontal movement
            horizontal_offset = self.create_sine_wave_movement(
                frame, 
                self.config["shuffle_amplitude"], 
                self.config["shuffle_speed"], 
                phase_offset
            )
            
            # Secondary wave for complex movement
            secondary_offset = self.create_sine_wave_movement(
                frame,
                self.config["shuffle_amplitude"] * 0.5,
                self.config["shuffle_speed"] * 1.5,
                phase_offset + pi/2
            )
            
            vertical_bounce = self.add_vertical_bounce(frame)
            
            pos = base_positions[helmet_num].copy()
            pos.x += horizontal_offset + secondary_offset
            pos.z += vertical_bounce
            
            positions[helmet_num] = pos
        
        return positions
    
    def apply_ease_out(self, frame):
        """Apply ease-out effect to slow down before reveal."""
        if not self.config["ease_out"]:
            return 1.0
        
        total_frames = self.config["duration_sec"] * self.config["fps"]
        ease_frames = self.config["ease_duration"] * self.config["fps"]
        ease_start_frame = total_frames - ease_frames
        
        if frame < ease_start_frame:
            return 1.0
        
        ease_progress = (frame - ease_start_frame) / ease_frames
        eased_value = self.ease_out_cubic(ease_progress)
        return max(0.3, eased_value)  # Minimum 30% movement to keep shuffle visible
    
    def detect_object_scale(self):
        """Detect the scale of objects in the scene to auto-adjust movement values."""
        if not self.props.auto_scale:
            return 1.0
        
        # Find the first helmet object (child of Empty_1)
        empty_1 = bpy.data.objects.get("Empty_1")
        if not empty_1 or not empty_1.children:
            return 1.0
        
        helmet = empty_1.children[0]  # First child is the helmet
        
        # Get the bounding box dimensions
        bbox_corners = [helmet.matrix_world @ mathutils.Vector(corner) for corner in helmet.bound_box]
        
        # Calculate the size of the helmet
        min_x = min(corner.x for corner in bbox_corners)
        max_x = max(corner.x for corner in bbox_corners)
        min_y = min(corner.y for corner in bbox_corners)
        max_y = max(corner.y for corner in bbox_corners)
        
        helmet_width = max_x - min_x
        helmet_depth = max_y - min_y
        helmet_size = max(helmet_width, helmet_depth)
        
        # Standard helmet size is about 0.3 units, so calculate scale factor
        standard_size = 0.3
        scale_factor = helmet_size / standard_size
        
        # Clamp scale factor to reasonable range
        scale_factor = max(0.1, min(50.0, scale_factor))
        
        # Update the detected scale property
        self.props.detected_scale = scale_factor
        
        print(f"🔍 Auto-detected object scale: {scale_factor:.2f}x (helmet size: {helmet_size:.2f} units)")
        
        return scale_factor
    
    def apply_auto_scale(self, scale_factor):
        """Apply auto-detected scale to movement parameters."""
        if not self.props.auto_scale:
            return
        
        # Base values for standard-sized objects
        base_amplitude = 2.0
        base_spacing = 1.5
        base_bounce = 0.3
        base_reveal_height = 1.0
        
        # Apply scale factor
        self.config["shuffle_amplitude"] = base_amplitude * scale_factor
        self.config["spacing_buffer"] = base_spacing * scale_factor
        self.config["vertical_bounce"] = base_bounce * scale_factor
        self.config["reveal_height"] = base_reveal_height * scale_factor
        
        # Update properties
        self.props.shuffle_amplitude = self.config["shuffle_amplitude"]
        self.props.spacing_buffer = self.config["spacing_buffer"]
        self.props.vertical_bounce = self.config["vertical_bounce"]
        self.props.reveal_height = self.config["reveal_height"]
        
        print(f"📏 Applied auto-scale: Amplitude={self.config['shuffle_amplitude']:.1f}, Spacing={self.config['spacing_buffer']:.1f}")

    def setup_scene(self):
        """Initialize scene settings with bulletproof validation."""
        # Validate scene setup first
        errors, warnings = self.validate_scene_setup()
        
        if errors:
            error_msg = "❌ Scene setup errors:\n" + "\n".join(f"• {error}" for error in errors)
            raise ValueError(error_msg)
        
        if warnings:
            warning_msg = "⚠️ Scene setup warnings:\n" + "\n".join(f"• {warning}" for warning in warnings)
            print(warning_msg)
        
        # Store original positions for undo functionality
        self.store_original_positions()
        
        # Set up scene
        bpy.context.scene.frame_set(1)
        bpy.context.scene.render.fps = self.config["fps"]
        
        # Auto-detect and apply scale
        scale_factor = self.detect_object_scale()
        self.apply_auto_scale(scale_factor)
        
        print("✅ Scene setup completed successfully!")
    
    def store_original_positions(self):
        """Store original positions for undo functionality."""
        required_empties = ["Empty_1", "Empty_2", "Empty_3", "Football_CTRL"]
        
        for empty_name in required_empties:
            obj = bpy.data.objects.get(empty_name)
            if obj:
                self.original_positions[empty_name] = obj.location.copy()
                self.original_rotations[empty_name] = obj.rotation_euler.copy()
        
        print("💾 Original positions stored for undo functionality")
    
    def restore_original_positions(self):
        """Restore original positions (undo functionality)."""
        for empty_name, position in self.original_positions.items():
            obj = bpy.data.objects.get(empty_name)
            if obj:
                obj.location = position
                obj.rotation_euler = self.original_rotations[empty_name]
        
        print("↩️ Original positions restored")
    
    def optimize_for_large_scenes(self):
        """Apply performance optimizations for large scenes."""
        if not self.props.optimize_large_scenes:
            return
        
        # Disable unnecessary updates during animation
        bpy.context.preferences.view.use_auto_perspective = False
        
        # Optimize viewport updates
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.overlay.show_overlays = False
        
        print("⚡ Performance optimizations applied for large scenes")
    
    def randomize_football_target(self):
        """Randomly choose which helmet hides the football."""
        if self.config["randomize_target"]:
            self.config["reveal_target"] = random.randint(1, 3)
            self.props.reveal_target = self.config["reveal_target"]
    
    def animate_helmets(self):
        """Create smooth shuffle animation for all helmets."""
        total_frames = int(self.config["duration_sec"] * self.config["fps"])
        
        for frame in range(1, total_frames + 1):
            positions = self.calculate_helmet_positions(frame)
            ease_factor = self.apply_ease_out(frame)
            
            for helmet_num in [1, 2, 3]:
                empty_name = f"Empty_{helmet_num}"
                empty_obj = self.get_empty_object(empty_name)
                
                pos = positions[helmet_num]
                
                # Apply easing only to movement offset, not base position
                base_pos = mathutils.Vector((-self.config["spacing_buffer"], 0, 0)) if helmet_num == 1 else \
                          mathutils.Vector((0, 0, 0)) if helmet_num == 2 else \
                          mathutils.Vector((self.config["spacing_buffer"], 0, 0))
                
                # Calculate movement offset and apply easing
                movement_offset = pos - base_pos
                movement_offset.x *= ease_factor
                movement_offset.z *= ease_factor
                
                # Final position = base + eased movement
                final_pos = base_pos + movement_offset
                
                empty_obj.location = final_pos
                empty_obj.keyframe_insert(data_path="location", frame=frame)
    
    def animate_football(self):
        """Animate football to follow the target helmet."""
        football_ctrl = self.get_empty_object("Football_CTRL")
        target_empty = self.get_empty_object(f"Empty_{self.config['reveal_target']}")
        
        total_frames = int(self.config["duration_sec"] * self.config["fps"])
        
        for frame in range(1, total_frames + 1):
            football_ctrl.location = target_empty.location
            football_ctrl.keyframe_insert(data_path="location", frame=frame)
    
    def create_reveal_animation(self):
        """Create dramatic reveal animation for the target helmet."""
        target_empty = self.get_empty_object(f"Empty_{self.config['reveal_target']}")
        football_ctrl = self.get_empty_object("Football_CTRL")
        
        total_frames = int(self.config["duration_sec"] * self.config["fps"])
        reveal_frames = int(self.config["reveal_duration"] * self.config["fps"])
        reveal_start_frame = total_frames - reveal_frames + 1
        
        final_pos = target_empty.location.copy()
        
        for i, frame in enumerate(range(reveal_start_frame, total_frames + 1)):
            progress = i / (reveal_frames - 1)
            ease_progress = self.ease_out_cubic(progress)
            
            reveal_pos = final_pos.copy()
            reveal_pos.z += self.config["reveal_height"] * ease_progress
            
            target_empty.location = reveal_pos
            target_empty.keyframe_insert(data_path="location", frame=frame)
            
            football_ctrl.location = final_pos
            football_ctrl.keyframe_insert(data_path="location", frame=frame)
    
    def animate_camera(self):
        """Add subtle camera sway for cinematic feel."""
        if not self.config["camera_sway"]:
            return
        
        camera = bpy.context.scene.camera
        if not camera:
            return
        
        total_frames = int(self.config["duration_sec"] * self.config["fps"])
        
        for frame in range(1, total_frames + 1):
            t = frame / (self.config["fps"] * self.config["duration_sec"])
            
            sway_x = self.config["sway_amount"] * sin(2 * pi * 0.5 * t)
            sway_y = self.config["sway_amount"] * cos(2 * pi * 0.3 * t)
            
            camera.rotation_euler.x += sway_x * 0.1
            camera.rotation_euler.y += sway_y * 0.1
            camera.keyframe_insert(data_path="rotation_euler", frame=frame)
    
    def set_render_settings(self):
        """Configure render settings for output."""
        scene = bpy.context.scene
        
        total_frames = int(self.config["duration_sec"] * self.config["fps"])
        scene.frame_start = 1
        scene.frame_end = total_frames
        
        scene.render.image_settings.file_format = 'PNG'
        scene.render.image_settings.color_mode = 'RGBA'
        scene.render.image_settings.color_depth = '16'
    
    def run_animation(self):
        """Execute the complete shell game animation."""
        try:
            self.setup_scene()
            self.randomize_football_target()
            self.animate_helmets()
            self.animate_football()
            self.create_reveal_animation()
            self.animate_camera()
            self.set_render_settings()
            return True, f"Animation complete! Football hidden under helmet {self.config['reveal_target']}"
        except Exception as e:
            return False, str(e)

# ============================================================================
# BLENDER OPERATOR
# ============================================================================

class LAURIER_OT_create_shell_game(Operator):
    """Create Laurier Football Shell Game Animation"""
    bl_idname = "laurier.create_shell_game"
    bl_label = "Create Shell Game Animation"
    bl_description = "Generate professional 3D shell game shuffle animation"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.laurier_shell_game
        
        try:
            # Apply preset if selected
            if props.preset != 'CUSTOM':
                self.apply_preset(props, props.preset)
            
            # Create and run animation engine with enhanced features
            engine = LaurierShellGameEngine(props)
            
            # Apply performance optimizations
            engine.optimize_for_large_scenes()
            
            # Run animation with bulletproof error handling
            success, message = engine.run_animation()
            
            if success:
                self.report({'INFO'}, f"🎉 {message}")
                return {'FINISHED'}
            else:
                self.report({'ERROR'}, f"❌ Animation failed: {message}")
                return {'CANCELLED'}
                
        except Exception as e:
            # Comprehensive error handling
            error_msg = f"❌ Unexpected error: {str(e)}"
            self.report({'ERROR'}, error_msg)
            print(f"Full error details: {e}")
            return {'CANCELLED'}
    
    def apply_preset(self, props, preset_name):
        """Apply preset configuration to properties."""
        presets = {
            'QUICK_SNAPPY': {
                'duration_sec': 5.0, 'shuffle_speed': 3.0, 'shuffle_cycles': 3,
                'shuffle_amplitude': 6.0, 'vertical_bounce': 1.0, 'spacing_buffer': 4.0,
                'reveal_duration': 1.0, 'reveal_height': 2.0, 'sway_amount': 0.05,
                'ease_duration': 0.8, 'randomize_target': True
            },
            'DRAMATIC_SLOW': {
                'duration_sec': 12.0, 'shuffle_speed': 1.2, 'shuffle_cycles': 6,
                'shuffle_amplitude': 15.0, 'vertical_bounce': 3.0, 'spacing_buffer': 10.0,
                'reveal_duration': 2.5, 'reveal_height': 6.0, 'sway_amount': 0.15,
                'ease_duration': 2.0, 'randomize_target': False
            },
            'SOCIAL_MEDIA': {
                'duration_sec': 3.0, 'fps': 30, 'shuffle_speed': 4.0, 'shuffle_cycles': 2,
                'shuffle_amplitude': 5.0, 'vertical_bounce': 2.0, 'spacing_buffer': 3.0,
                'reveal_duration': 0.8, 'reveal_height': 3.0, 'sway_amount': 0.2,
                'ease_out': False, 'ease_duration': 0.5, 'randomize_target': True
            },
            'BROADCAST_QUALITY': {
                'duration_sec': 8.0, 'shuffle_speed': 3.5, 'shuffle_cycles': 4,
                'shuffle_amplitude': 12.0, 'vertical_bounce': 2.0, 'spacing_buffer': 8.0,
                'reveal_duration': 1.5, 'reveal_height': 4.0, 'sway_amount': 0.1,
                'ease_duration': 1.0, 'randomize_target': True
            },
            'MINIMAL_CLEAN': {
                'duration_sec': 6.0, 'shuffle_speed': 1.5, 'shuffle_cycles': 3,
                'shuffle_amplitude': 6.0, 'vertical_bounce': 0.5, 'spacing_buffer': 9.0,
                'reveal_duration': 1.2, 'reveal_height': 2.0, 'camera_sway': False,
                'sway_amount': 0.0, 'ease_duration': 1.5, 'randomize_target': False
            },
            'HIGH_ENERGY': {
                'duration_sec': 4.0, 'fps': 30, 'shuffle_speed': 3.5, 'shuffle_cycles': 3,
                'shuffle_amplitude': 9.0, 'vertical_bounce': 3.0, 'spacing_buffer': 6.0,
                'reveal_duration': 1.0, 'reveal_height': 5.0, 'sway_amount': 0.25,
                'ease_out': False, 'ease_duration': 0.5, 'randomize_target': True
            }
        }
        
        if preset_name in presets:
            for key, value in presets[preset_name].items():
                setattr(props, key, value)

class LAURIER_OT_set_scale_preset(Operator):
    """Set scale preset for object size"""
    bl_idname = "laurier.set_scale_preset"
    bl_label = "Set Scale Preset"
    bl_description = "Quickly set movement values for different object scales"
    bl_options = {'REGISTER', 'UNDO'}
    
    preset: bpy.props.StringProperty()
    
    def execute(self, context):
        props = context.scene.laurier_shell_game
        
        scale_presets = {
            'SMALL': {
                'shuffle_amplitude': 2.0,
                'spacing_buffer': 1.5,
                'vertical_bounce': 0.3,
                'reveal_height': 1.0
            },
            'LARGE': {
                'shuffle_amplitude': 12.0,
                'spacing_buffer': 8.0,
                'vertical_bounce': 2.0,
                'reveal_height': 4.0
            },
            'HUGE': {
                'shuffle_amplitude': 25.0,
                'spacing_buffer': 15.0,
                'vertical_bounce': 5.0,
                'reveal_height': 8.0
            }
        }
        
        if self.preset in scale_presets:
            for key, value in scale_presets[self.preset].items():
                setattr(props, key, value)
            
            self.report({'INFO'}, f"Applied {self.preset.lower()} object scale preset")
        
        return {'FINISHED'}

class LAURIER_OT_set_movement_preset(Operator):
    """Set movement intensity preset"""
    bl_idname = "laurier.set_movement_preset"
    bl_label = "Set Movement Preset"
    bl_description = "Quickly set movement intensity"
    bl_options = {'REGISTER', 'UNDO'}
    
    preset: bpy.props.StringProperty()
    
    def execute(self, context):
        props = context.scene.laurier_shell_game
        
        movement_presets = {
            'SUBTLE': {
                'shuffle_amplitude': props.shuffle_amplitude * 0.5,
                'vertical_bounce': props.vertical_bounce * 0.3,
                'shuffle_speed': 1.5
            },
            'NORMAL': {
                'shuffle_amplitude': props.shuffle_amplitude,
                'vertical_bounce': props.vertical_bounce,
                'shuffle_speed': 2.5
            },
            'DRAMATIC': {
                'shuffle_amplitude': props.shuffle_amplitude * 1.5,
                'vertical_bounce': props.vertical_bounce * 1.5,
                'shuffle_speed': 4.0
            }
        }
        
        if self.preset in movement_presets:
            for key, value in movement_presets[self.preset].items():
                setattr(props, key, value)
            
            self.report({'INFO'}, f"Applied {self.preset.lower()} movement preset")
        
        return {'FINISHED'}

class LAURIER_OT_detect_scale(Operator):
    """Detect object scale and apply auto-scaling"""
    bl_idname = "laurier.detect_scale"
    bl_label = "Detect Scale"
    bl_description = "Analyze your objects and automatically adjust movement values"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.laurier_shell_game
        
        # Create temporary engine to detect scale
        engine = LaurierShellGameEngine(props)
        scale_factor = engine.detect_object_scale()
        engine.apply_auto_scale(scale_factor)
        
        self.report({'INFO'}, f"Auto-detected scale: {scale_factor:.1f}x - Movement values adjusted!")
        return {'FINISHED'}

class LAURIER_OT_validate_scene(Operator):
    """Validate scene setup and provide detailed feedback"""
    bl_idname = "laurier.validate_scene"
    bl_label = "Validate Scene"
    bl_description = "Check scene setup and provide detailed feedback"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.laurier_shell_game
        engine = LaurierShellGameEngine(props)
        
        try:
            errors, warnings = engine.validate_scene_setup()
            
            if not errors and not warnings:
                self.report({'INFO'}, "✅ Scene setup is perfect! Ready for animation.")
            elif not errors:
                warning_msg = "⚠️ Scene has warnings but is usable: " + "; ".join(warnings[:2])
                self.report({'WARNING'}, warning_msg)
            else:
                error_msg = "❌ Scene setup errors: " + "; ".join(errors[:2])
                self.report({'ERROR'}, error_msg)
            
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Validation failed: {str(e)}")
            return {'CANCELLED'}

class LAURIER_OT_preview_animation(Operator):
    """Preview animation in viewport"""
    bl_idname = "laurier.preview_animation"
    bl_label = "Preview Animation"
    bl_description = "Show real-time preview of the animation"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.laurier_shell_game
        
        if not props.preview_mode:
            self.report({'WARNING'}, "Preview mode is disabled. Enable it in settings first.")
            return {'CANCELLED'}
        
        try:
            # Create temporary animation for preview
            engine = LaurierShellGameEngine(props)
            engine.setup_scene()
            
            # Generate preview frames (first 2 seconds)
            preview_frames = int(2.0 * props.fps)
            for frame in range(1, preview_frames + 1):
                positions = engine.calculate_helmet_positions(frame)
                for helmet_num in [1, 2, 3]:
                    empty_name = f"Empty_{helmet_num}"
                    empty_obj = engine.get_empty_object(empty_name)
                    empty_obj.location = positions[helmet_num]
            
            self.report({'INFO'}, f"🎬 Preview generated for {preview_frames} frames")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Preview failed: {str(e)}")
            return {'CANCELLED'}

class LAURIER_OT_undo_animation(Operator):
    """Undo the last animation"""
    bl_idname = "laurier.undo_animation"
    bl_label = "Undo Animation"
    bl_description = "Restore original positions before animation"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.laurier_shell_game
        
        if not props.undo_enabled:
            self.report({'WARNING'}, "Undo is disabled. Enable it in settings first.")
            return {'CANCELLED'}
        
        try:
            engine = LaurierShellGameEngine(props)
            engine.restore_original_positions()
            
            self.report({'INFO'}, "↩️ Animation undone - original positions restored")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Undo failed: {str(e)}")
            return {'CANCELLED'}

class LAURIER_OT_quick_setup(Operator):
    """Quick setup wizard for scene preparation"""
    bl_idname = "laurier.quick_setup"
    bl_label = "Quick Setup"
    bl_description = "Automatically create required empty objects and setup scene"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        try:
            # Create required empty objects if they don't exist
            required_empties = ["Empty_1", "Empty_2", "Empty_3", "Football_CTRL"]
            created_objects = []
            
            for empty_name in required_empties:
                if not bpy.data.objects.get(empty_name):
                    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
                    new_empty = bpy.context.active_object
                    new_empty.name = empty_name
                    created_objects.append(empty_name)
            
            if created_objects:
                self.report({'INFO'}, f"✅ Created empty objects: {', '.join(created_objects)}")
            else:
                self.report({'INFO'}, "✅ All required objects already exist")
            
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Quick setup failed: {str(e)}")
            return {'CANCELLED'}

# ============================================================================
# USER INTERFACE PANEL
# ============================================================================

class LAURIER_PT_shell_game_panel(Panel):
    """Panel for Laurier Shell Game controls"""
    bl_label = "Laurier Football Shell Game"
    bl_idname = "LAURIER_PT_shell_game_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Laurier Football"
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.laurier_shell_game
        
        # Compact Header
        header_box = layout.box()
        header_box.label(text="🏈 Laurier Football Shell Game v2.1", icon='ARMATURE_DATA')
        
        # Quick Actions - Compact
        actions_row = header_box.row(align=True)
        actions_row.operator("laurier.quick_setup", text="Setup", icon='TOOL_SETTINGS')
        actions_row.operator("laurier.validate_scene", text="Validate", icon='CHECKMARK')
        actions_row.operator("laurier.detect_scale", text="Auto-Scale", icon='VIEWZOOM')
        
        # Auto-Scale Section
        layout.separator()
        scale_box = layout.box()
        scale_row = scale_box.row(align=True)
        scale_row.prop(props, "auto_scale", text="Auto Scale", icon='AUTO' if props.auto_scale else 'SETTINGS')
        
        if props.auto_scale:
            scale_info = scale_box.row(align=True)
            scale_info.label(text=f"Scale: {props.detected_scale:.1f}x", icon='INFO')
        
        # Movement Controls - Most Important
        layout.separator()
        movement_box = layout.box()
        movement_box.label(text="🎮 Movement", icon='MESH_MONKEY')
        
        # Compact sliders
        col = movement_box.column(align=True)
        col.prop(props, "shuffle_amplitude", slider=True, text="Distance")
        col.prop(props, "spacing_buffer", slider=True, text="Spacing")
        col.prop(props, "vertical_bounce", slider=True, text="Bounce")
        
        # Intensity buttons
        intensity_row = movement_box.row(align=True)
        intensity_row.operator("laurier.set_movement_preset", text="Subtle").preset = 'SUBTLE'
        intensity_row.operator("laurier.set_movement_preset", text="Normal").preset = 'NORMAL'
        intensity_row.operator("laurier.set_movement_preset", text="Dramatic").preset = 'DRAMATIC'
        
        # Preset Selection
        layout.separator()
        preset_box = layout.box()
        preset_box.label(text="🎯 Preset", icon='PRESET')
        preset_box.prop(props, "preset", text="")
        
        # Main Action Button
        layout.separator()
        create_row = layout.row(align=True)
        create_row.scale_y = 2.0
        create_row.operator("laurier.create_shell_game", text="🎬 Create Animation", icon='PLAY')
        
        # Secondary Actions
        secondary_row = layout.row(align=True)
        secondary_row.operator("laurier.preview_animation", text="Preview", icon='HIDE_OFF')
        secondary_row.operator("laurier.undo_animation", text="Undo", icon='LOOP_BACK')
        
        # Status Info
        layout.separator()
        status_box = layout.box()
        status_box.label(text="📊 Status", icon='INFO')
        
        status_col = status_box.column(align=True)
        status_col.label(text=f"Duration: {props.duration_sec}s")
        status_col.label(text=f"Movement: {props.shuffle_amplitude:.1f}")
        status_col.label(text=f"Target: Helmet {props.reveal_target}")
        
        # Advanced Settings (Collapsed by default)
        layout.separator()
        advanced_box = layout.box()
        advanced_header = advanced_box.row(align=True)
        advanced_header.label(text="⚙️ Advanced", icon='PREFERENCES')
        
        # Show advanced settings in compact form
        adv_col = advanced_box.column(align=True)
        adv_col.prop(props, "preview_mode", text="Preview Mode")
        adv_col.prop(props, "undo_enabled", text="Enable Undo")
        adv_col.prop(props, "optimize_large_scenes", text="Optimize Performance")
        
        # Custom Settings (Only if Custom preset)
        if props.preset == 'CUSTOM':
            layout.separator()
            custom_box = layout.box()
            custom_box.label(text="🎛️ Custom Settings", icon='TOOL_SETTINGS')
            
            custom_col = custom_box.column(align=True)
            custom_col.prop(props, "duration_sec", text="Duration")
            custom_col.prop(props, "fps", text="FPS")
            custom_col.prop(props, "shuffle_speed", text="Speed")
            custom_col.prop(props, "reveal_target", text="Target")
            custom_col.prop(props, "randomize_target", text="Random Target")
        
        # Help Tips
        layout.separator()
        help_box = layout.box()
        help_box.label(text="💡 Tips", icon='HELP')
        
        tips_col = help_box.column(align=True)
        tips_col.label(text="• Use Auto-Scale for any size")
        tips_col.label(text="• Validate checks setup")
        tips_col.label(text="• Preview before creating")

# ============================================================================
# REGISTRATION
# ============================================================================

classes = (
    LaurierShellGameProperties,
    LAURIER_OT_create_shell_game,
    LAURIER_OT_set_scale_preset,
    LAURIER_OT_set_movement_preset,
    LAURIER_OT_detect_scale,
    LAURIER_OT_validate_scene,
    LAURIER_OT_preview_animation,
    LAURIER_OT_undo_animation,
    LAURIER_OT_quick_setup,
    LAURIER_PT_shell_game_panel,
)

def register():
    """Register the addon."""
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.laurier_shell_game = PointerProperty(type=LaurierShellGameProperties)
    print("🏈 Laurier Football Shell Game Addon registered successfully!")

def unregister():
    """Unregister the addon."""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.laurier_shell_game
    print("🏈 Laurier Football Shell Game Addon unregistered.")

if __name__ == "__main__":
    register()
