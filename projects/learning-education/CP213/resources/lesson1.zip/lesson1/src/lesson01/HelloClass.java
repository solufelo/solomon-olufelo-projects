package lesson01;

import java.util.Scanner;

/*
 * this is your first program
 * HelloClass prints hello to screen and 
 * adds two numbers
 */
public class HelloClass {

	// main method
	public static void main(String args[]) {
		System.out.println("Hello Class");
		System.out.println("Welcome to CP 213");
		System.out.println("Let's add two numbers");
		int result = 0;
		result = 2 + 2;
		System.out.println("two plus two is " + result);

		String a = "hello ";
		String b = "World";
		String c = "Say ";

		c = b = a;
		System.out.println(c);

	}
}
