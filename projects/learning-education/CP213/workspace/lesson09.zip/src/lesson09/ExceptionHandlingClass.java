package lesson09;

public class ExceptionHandlingClass {
//
//	public staitc void main (String args [] ) {
//		
//		try	{
//		  CodeThatMayThrowAnException
//		}
//
//		throw new 
//		  ExceptionClassName(PossiblySomeArguments);
//
//	}
//	


}
